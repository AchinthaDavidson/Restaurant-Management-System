const express = require("express");
const passport = require("passport");
const router = express.Router();
const userController = require("../controllers/user.controller");

router.post("/signin", userController.signIn);
router.post("/signup", userController.signUp);
router.post("/googleauth", userController.googleAuth);
// router.get(
//   "/google",
//   passport.authenticate("google", { scope: ["profile", "email"] })
// );

// router.get(
//   "/google/callback",
//   passport.authenticate("google", {
//     session: false,
//     successRedirect: process.env.FRONTEND_URL,
//     failureRedirect: "/auth/signin",
//   }),
//   userController.googleAuth
// );

router.post("/send-otp", userController.sendOTP);
router.post("/change-password", userController.changePassword);

module.exports = router;
